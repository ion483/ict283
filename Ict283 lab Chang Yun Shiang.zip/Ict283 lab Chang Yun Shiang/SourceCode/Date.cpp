#include "Date.h"

// default constructor
Date::Date(){
    m_year = 0;
    m_month = 0;
    m_day = 0;
    m_isValid = false;
}

// paremeterized constructor
Date::Date(int year, int monthInt, int day){
    if(!checkDate(year, monthInt, day)){
        m_year = 0;
        m_month = 0;
        m_day = 0;
        m_isValid = false;
        return;
    }
    m_year = year;
    m_month = monthInt;
    m_day = day;
    m_isValid = true;
}

// m_year getter
void Date::getYear(int& year) const{
    year = m_year;
}

// m_year setter
void Date::setYear(int newYear){
    if(newYear >= 0) m_year = newYear;
    m_isValid = checkDate(m_year, m_month, m_day);
}

// m_month getter
void Date::getMonth(int& month) const{
    month = m_month;
}

// m_month setter
void Date::setMonth(int newMonth){
    if(newMonth > 0 && newMonth < 13) m_month = newMonth;
    m_isValid = checkDate(m_year, m_month, m_day);
}

// m_day getter
void Date::getDay(int& day) const{
    day = m_day;
}

// m_day setter
void Date::setDay(int newDay){
    if(newDay > 0 && newDay < 32) m_day = newDay;
    m_isValid = checkDate(m_year, m_month, m_day);
}

// helper for month int to month string
const std::string* Date::monthToStr(int monthNumber) const{
    static const std::string months[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    if(monthNumber <= 0 || monthNumber >= 13) return nullptr;
    return &months[monthNumber-1];
}

// helper for month string to month int
int Date::monthStrToInt(const std::string& monthStr) const{
    static const std::string months[12] = {"january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"};
    std::string lowerMonthStr = monthStr;
    
    for(int i = 0; i < lowerMonthStr.length(); i++){
        lowerMonthStr[i] = std::tolower(lowerMonthStr[i]);
    }

    std::regex pattern(" ");
    std::string formattedLowerMonthStr = std::regex_replace(lowerMonthStr, pattern, "");

    for(int i = 0; i < 12; i++){
        if(months[i] == formattedLowerMonthStr){
            return i + 1;
        }
    }
    return -1;
}

bool Date::checkDate(int year, int month, int day) const{
    if(year < 0) return false;
    if(month <= 0 || month >= 13) return false;
    if(day <= 0 || day >= 32) return false;
    return true;
}

bool Date::isValid() const{
    return m_isValid;
}

// date equality comparison operator
bool Date::operator==(const Date& other) const{
    return other.m_year == m_year && other.m_month == m_month && other.m_day == m_day;
}

// date greater comparison operator
bool Date::operator>(const Date& other) const{
    if(other.m_year != m_year) return m_year > other.m_year;
    if(other.m_month != m_month) return m_month > other.m_month;
    return m_day > other.m_day;
}

// date less comparison operator
bool Date::operator<(const Date& other) const{
    return other > *this;
}

/*
std::istream& operator>>(std::istream& is, Date& d){
    int year, monthInt, day;

    char month[maxMonthSize];
    std::string cellstr;
    is >> cellstr;
    const char delimiter = ',';
    std::regex pattern(",");
    std::string formattedString = std::regex_replace(cellstr, pattern, " ");
    std::istringstream fiss(formattedString);
    fiss >> year >> monthInt >> day;
    
    const std::string* monthPtr = d.monthToStr(monthInt);
    std::string monthstr = *monthPtr;
    std::strncpy(month, monthstr.c_str(), maxMonthSize-1);
    month[maxMonthSize-1] = '\0';

    d.setYear(year);
    d.setMonth(month);
    d.setDay(day);
    return is;
}
*/


// date input operator
/*so in the input operator, we designed a two layer filtering for setting year, month, and day,
  the first layer is parsing, we ensured there is no error during parsing for day and year,
  the second layer is constraint checking, after parsing, we check if the day is withing the constraint,
  and the month string should also fit the constraint, and after these two layers, if there is no error, 
  then we can set year, month, and day of the Date object, eles it will be all 0.
 */
std::istream& operator>>(std::istream& is, Date& d){
    std::string inputStr;
    std::getline(is, inputStr);

    std::istringstream iss(inputStr);
    const char delimiter = '/';
    std::string cell;
    int day, month, year;
    std::string monthStr;
    try{ // if any of the day, month, and year has problem with conversion, the whole date remains unchanged
        std::getline(iss, cell, delimiter);
        day = std::stoi(cell);
        std::getline(iss, cell, delimiter);
        monthStr = cell;
        month = d.monthStrToInt(monthStr);
        std::getline(iss, cell, delimiter);
        year = std::stoi(cell);

        if(!d.checkDate(year, month, day)) throw std::invalid_argument("Invalid Date");

        d.setYear(year);
        d.setMonth(month);
        d.setDay(day);
    }catch(const std::exception& e){
        std::cout << "Input operator failed for Date" << std::endl;
    }
    return is;
}

// date output operator
std::ostream& operator<<(std::ostream& os, const Date& d){
    int year, monthInt, day;
    d.getYear(year);
    d.getMonth(monthInt);
    d.getDay(day);

    const std::string* monthptr = d.monthToStr(monthInt);
    std::string month;
    if(monthptr != nullptr){
        month = *monthptr;
    }else{
        month = "Unknown-Month";
    }
    

    os << "  Date:      ";
    if(day >= 32 || day <= 0){
        os << "Unknown-Day" << ' ';
    }else{
        if(day < 10){
            os << "0" << day << ' ';
        }else{
            os << day << ' ';
        }
    }
    os << month << ' ';
    os << year;
    
    os << '\n';
    return os;
}