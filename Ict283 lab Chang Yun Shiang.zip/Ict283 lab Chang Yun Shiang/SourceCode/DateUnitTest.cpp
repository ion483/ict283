#include "Date.h"
#include <cassert>
#include <fstream>

int main(){
    Date d;
    std::string isValid = (d.isValid())? "valid": "invalid";
    std::cout << "is d valid: " << isValid << '\n';

    d.setYear(2020);
    std::cout << "set the year\n";
    isValid = (d.isValid())? "valid": "invalid";
    std::cout << "is d valid: " << isValid << '\n';

    d.setMonth(5);
    std::cout << "set the month\n";
    isValid = (d.isValid())? "valid": "invalid";
    std::cout << "is d valid: " << isValid << '\n';

    d.setDay(10);
    std::cout << "set the day\n";
    isValid = (d.isValid())? "valid": "invalid";
    std::cout << "is d valid: " << isValid << '\n';


    Date inputDate;
    std::istringstream iss1("05/May/2020");
    iss1 >> inputDate;
    std::cout << inputDate << "is inputDate valid: \n" << inputDate.isValid() << '\n';

    Date inputDate2;
    std::istringstream iss2("0/May/2020");
    iss2 >> inputDate;
    std::cout << '\n' << inputDate2 << "is inputDate2 valid: \n" << inputDate2.isValid() << '\n';

    Date inputDate3;
    std::istringstream iss3("10/J u n e/2016");
    iss3 >> inputDate3;
    std::cout << '\n' << inputDate3 << "is inputDate3 valid: \n" << inputDate3.isValid() << '\n';


    int year, month, day;
    d.getYear(year);
    d.getMonth(month);
    d.getDay(day);

    std::cout << "d: " << d << '\n';

    assert((year == 2020) && (month == 5) && (day == 10));

    Date d2(2018, 2, 5);
    
    std::cout << "d2: " << d2 << '\n';

    std::cout << "d == d2? " << (d == d2? "Yes": "No") << '\n';
    std::cout << "d < d2? " << (d < d2? "Yes": "No") << '\n';
    std::cout << "d > d2? " << (d > d2? "Yes": "No") << '\n';

    std::ifstream ifs("DateInputTest.txt");
    Date dateArray[50];
    int lineCount = 0;
    std::string dateCell;
    while(std::getline(ifs, dateCell)){
        lineCount++;
    }
    
    ifs.clear();
    ifs.seekg(0);

    for(int i = 0; i < lineCount; i++){
        Date d;
        ifs >> d;
        dateArray[i] = d;
    }

    for(int i = 0; i < lineCount; i++){
        std::cout << dateArray[i] << '\n';
    }

    std::cout << "Date class passes all tests" << std::endl;


    return 0;
}