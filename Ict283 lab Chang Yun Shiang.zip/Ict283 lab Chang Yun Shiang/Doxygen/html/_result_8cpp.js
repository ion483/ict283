var _result_8cpp =
[
    [ "operator<<", "_result_8cpp.html#a858c35eb833d773dbd9de8223e04b0c2", null ],
    [ "operator>>", "_result_8cpp.html#a6949d72b46deca48d9142f13c680a742", null ]
];