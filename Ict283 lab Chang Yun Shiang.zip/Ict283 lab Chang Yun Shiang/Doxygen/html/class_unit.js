var class_unit =
[
    [ "Unit", "class_unit.html#a8e46f663a95736c8002d85ab271a7581", null ],
    [ "Unit", "class_unit.html#a2c308b3f816ca865b14391a9d0030772", null ],
    [ "GetCredits", "class_unit.html#a80031589d556c0802b70e4b4ac910448", null ],
    [ "GetId", "class_unit.html#a823afcfcfe5dff65b3485893fbc6229c", null ],
    [ "GetName", "class_unit.html#a6c6e4a940b624c50df7d2087d3d67515", null ],
    [ "SetCredits", "class_unit.html#ad325e0da665fad02ad51479cc1db2386", null ],
    [ "SetId", "class_unit.html#ac9b8bcb05ad741c1d9aa7d5bc52e7e00", null ],
    [ "SetName", "class_unit.html#a386471443734e662f86c8ea6460e7413", null ],
    [ "credits", "class_unit.html#a627d3712effeee964df5f6c67afc57d9", null ],
    [ "id", "class_unit.html#a1c21cd9313142f71b62b06688d18bdac", null ],
    [ "name", "class_unit.html#a03a2344fa6977a2ce44b320e44bc9caa", null ]
];