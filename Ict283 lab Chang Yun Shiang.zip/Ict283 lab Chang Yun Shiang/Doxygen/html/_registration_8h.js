var _registration_8h =
[
    [ "Registration", "class_registration.html", "class_registration" ],
    [ "operator<<", "_registration_8h.html#a1420aaeba63d13fa706404daee7bcc2b", null ],
    [ "operator>>", "_registration_8h.html#af1f09fcf2f667baebddc9ee2d014cc50", null ],
    [ "MaxResults", "_registration_8h.html#acaceade9084d64028f3558082708ebae", null ]
];