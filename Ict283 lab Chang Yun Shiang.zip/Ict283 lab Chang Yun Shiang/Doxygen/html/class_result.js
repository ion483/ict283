var class_result =
[
    [ "Result", "class_result.html#a90f44667e23d25ccdeac37f00a74657b", null ],
    [ "Result", "class_result.html#aef6c27f739f37bbf986326e92ade489e", null ],
    [ "GetCredits", "class_result.html#af48fd3e2f01453f2fefcea9e870c654a", null ],
    [ "GetDate", "class_result.html#a2d701abe66b96a1d6723a5835e744309", null ],
    [ "GetMark", "class_result.html#a57f9f7150a515c5f0e997682b2b97f1d", null ],
    [ "GetUnit", "class_result.html#a8a442d311e4868f8e6094d8b3c2a02fa", null ],
    [ "SetDate", "class_result.html#a00c7a6a0d2202eaeb5bd2a62afcdeeb1", null ],
    [ "SetMark", "class_result.html#af78d4374e34ebefcace359c664b5e9ee", null ],
    [ "SetUnit", "class_result.html#afa924341881402d45d00702e7bf88886", null ],
    [ "m_date", "class_result.html#a2bfb59cd958e73627e4efce955e9c16e", null ],
    [ "m_mark", "class_result.html#a502b358cd02ddffe8482938dbe892edc", null ],
    [ "m_unit", "class_result.html#a5f50ed6974abac33aad2b07184193663", null ]
];