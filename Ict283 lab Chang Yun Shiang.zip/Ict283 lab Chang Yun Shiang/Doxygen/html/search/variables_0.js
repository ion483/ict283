var searchData=
[
  ['count_0',['count',['../class_registration.html#af637abb1cea06f459b8ddbf02522cc1a',1,'Registration']]],
  ['credits_1',['credits',['../class_unit.html#a627d3712effeee964df5f6c67afc57d9',1,'Unit']]]
];
