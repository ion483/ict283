var searchData=
[
  ['registration_0',['Registration',['../class_registration.html#aac811faf22fe96a7f657a282d6d679ab',1,'Registration']]],
  ['result_1',['Result',['../class_result.html#a90f44667e23d25ccdeac37f00a74657b',1,'Result::Result()'],['../class_result.html#aef6c27f739f37bbf986326e92ade489e',1,'Result::Result(const Unit &amp;u, float mark, const Date &amp;d)']]]
];
