var searchData=
[
  ['semester_0',['semester',['../class_registration.html#a4ebe7e268a8a20bc9d9d4501ab78d7ed',1,'Registration']]],
  ['studentid_1',['studentId',['../class_registration.html#afd5372c81feb6789de53e214cce5de98',1,'Registration']]]
];
