var searchData=
[
  ['semester_0',['semester',['../class_registration.html#a4ebe7e268a8a20bc9d9d4501ab78d7ed',1,'Registration']]],
  ['setcount_1',['SetCount',['../class_registration.html#aa16024e0f5852847ea0ef362b7a7d968',1,'Registration']]],
  ['setcredits_2',['SetCredits',['../class_unit.html#ad325e0da665fad02ad51479cc1db2386',1,'Unit']]],
  ['setdate_3',['SetDate',['../class_result.html#a00c7a6a0d2202eaeb5bd2a62afcdeeb1',1,'Result']]],
  ['setday_4',['setDay',['../class_date.html#a736d057ba05ddb2e078cc010f0d48449',1,'Date']]],
  ['setid_5',['SetId',['../class_unit.html#ac9b8bcb05ad741c1d9aa7d5bc52e7e00',1,'Unit']]],
  ['setmark_6',['SetMark',['../class_result.html#af78d4374e34ebefcace359c664b5e9ee',1,'Result']]],
  ['setmonth_7',['setMonth',['../class_date.html#a72d9e45da4dbc9d15f8c5c7e4d8d0cbb',1,'Date']]],
  ['setname_8',['SetName',['../class_unit.html#a386471443734e662f86c8ea6460e7413',1,'Unit']]],
  ['setresult_9',['SetResult',['../class_registration.html#a47975c77bfa52a2f5fde1f184fc54603',1,'Registration']]],
  ['setsemester_10',['SetSemester',['../class_registration.html#a2333e72de290078b5c5b90040278aa63',1,'Registration']]],
  ['setstudentid_11',['SetStudentId',['../class_registration.html#aa9826f4d22d54d33cde356bd2a82d3d7',1,'Registration']]],
  ['setunit_12',['SetUnit',['../class_result.html#afa924341881402d45d00702e7bf88886',1,'Result']]],
  ['setyear_13',['setYear',['../class_date.html#a5bee9e5d7e2ecec12a0af6cf81a68e1b',1,'Date']]],
  ['studentid_14',['studentId',['../class_registration.html#afd5372c81feb6789de53e214cce5de98',1,'Registration']]]
];
