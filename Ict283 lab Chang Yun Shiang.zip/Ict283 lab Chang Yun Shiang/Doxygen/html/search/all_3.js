var searchData=
[
  ['getcount_0',['GetCount',['../class_registration.html#a507c39e9fa89a44ab02e48ae70349437',1,'Registration']]],
  ['getcredits_1',['GetCredits',['../class_registration.html#abe504283c246964fe7ca9ff276ce932c',1,'Registration::GetCredits()'],['../class_result.html#af48fd3e2f01453f2fefcea9e870c654a',1,'Result::GetCredits()'],['../class_unit.html#a80031589d556c0802b70e4b4ac910448',1,'Unit::GetCredits()']]],
  ['getdate_2',['GetDate',['../class_result.html#a2d701abe66b96a1d6723a5835e744309',1,'Result']]],
  ['getday_3',['getDay',['../class_date.html#a210251fce62edabb4cbbc160322a3732',1,'Date']]],
  ['getid_4',['GetId',['../class_unit.html#a823afcfcfe5dff65b3485893fbc6229c',1,'Unit']]],
  ['getmark_5',['GetMark',['../class_result.html#a57f9f7150a515c5f0e997682b2b97f1d',1,'Result']]],
  ['getmonth_6',['getMonth',['../class_date.html#add7d1b15199adad746af7197c0299042',1,'Date']]],
  ['getname_7',['GetName',['../class_unit.html#a6c6e4a940b624c50df7d2087d3d67515',1,'Unit']]],
  ['getresult_8',['GetResult',['../class_registration.html#a4a1bf6dbcf583d82a731884603ec4403',1,'Registration']]],
  ['getsemester_9',['GetSemester',['../class_registration.html#a3fd9d1d4472df6eea961cd73d6175902',1,'Registration']]],
  ['getstudentid_10',['GetStudentId',['../class_registration.html#a6990cb893bf04550ad073bc2cb4b49a9',1,'Registration']]],
  ['getunit_11',['GetUnit',['../class_result.html#a8a442d311e4868f8e6094d8b3c2a02fa',1,'Result']]],
  ['getyear_12',['getYear',['../class_date.html#a2d786001c23bc539935dfc1e67411669',1,'Date']]]
];
