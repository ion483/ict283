var searchData=
[
  ['unit_0',['Unit',['../class_unit.html#a8e46f663a95736c8002d85ab271a7581',1,'Unit::Unit()'],['../class_unit.html#a2c308b3f816ca865b14391a9d0030772',1,'Unit::Unit(const std::string &amp;nam, const std::string &amp;idp, int cred)']]]
];
