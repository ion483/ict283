var indexSectionsWithContent =
{
  0: "bcdgilmnorsu",
  1: "dru",
  2: "dmru",
  3: "cdgimorsu",
  4: "cimnrs",
  5: "bl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

