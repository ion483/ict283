var _registration_8cpp =
[
    [ "operator<<", "_registration_8cpp.html#a1420aaeba63d13fa706404daee7bcc2b", null ],
    [ "operator>>", "_registration_8cpp.html#af1f09fcf2f667baebddc9ee2d014cc50", null ]
];