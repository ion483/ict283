var class_registration =
[
    [ "Registration", "class_registration.html#aac811faf22fe96a7f657a282d6d679ab", null ],
    [ "GetCount", "class_registration.html#a507c39e9fa89a44ab02e48ae70349437", null ],
    [ "GetCredits", "class_registration.html#abe504283c246964fe7ca9ff276ce932c", null ],
    [ "GetResult", "class_registration.html#a4a1bf6dbcf583d82a731884603ec4403", null ],
    [ "GetSemester", "class_registration.html#a3fd9d1d4472df6eea961cd73d6175902", null ],
    [ "GetStudentId", "class_registration.html#a6990cb893bf04550ad073bc2cb4b49a9", null ],
    [ "SetCount", "class_registration.html#aa16024e0f5852847ea0ef362b7a7d968", null ],
    [ "SetResult", "class_registration.html#a47975c77bfa52a2f5fde1f184fc54603", null ],
    [ "SetSemester", "class_registration.html#a2333e72de290078b5c5b90040278aa63", null ],
    [ "SetStudentId", "class_registration.html#aa9826f4d22d54d33cde356bd2a82d3d7", null ],
    [ "count", "class_registration.html#af637abb1cea06f459b8ddbf02522cc1a", null ],
    [ "results", "class_registration.html#a8f109885d01df2072701b219611a4abe", null ],
    [ "semester", "class_registration.html#a4ebe7e268a8a20bc9d9d4501ab78d7ed", null ],
    [ "studentId", "class_registration.html#afd5372c81feb6789de53e214cce5de98", null ]
];